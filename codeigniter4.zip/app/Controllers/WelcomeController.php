<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class WelcomeController extends BaseController
{
    public function index()
    {
        $data = [
            // 'page' => 'header',
            'title' => 'CodeIgniter 4 with Twig',
            'content' => 'Hello from Twig!'
        ];
        $data['items'] = [
            0 => [
                'name' => 'Pant',
                'price' => 1000
            ],
            1 => [
                'name' => 'Shirt',
                'price' => 1000
            ]
        ];
        $data['headerPartial'] = 'partials/header.html';
        $data['footerPartial'] = 'partials/footer.html';

        echo $this->twig->render('welcome.html', $data);
    }
}
